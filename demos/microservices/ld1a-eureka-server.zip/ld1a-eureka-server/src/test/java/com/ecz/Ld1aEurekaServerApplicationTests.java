package com.ecz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ld1aEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
